const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const zlib = require("zlib");
let Pool = null;
try{({Pool}=require("pg"));}catch(error){if(process.env.DATABASE_URL)console.error("Postgres driver unavailable:",error.message);}

const VERSION = "0.4.0";
const PORT = Number(process.env.PORT || 3000);
const publicDir = path.join(__dirname, "public");
const dataDir = process.env.DATA_DIR || path.join(__dirname, "data");
const savesFile = path.join(dataDir, "saves.json");
const settingsFile = path.join(dataDir, "settings.json");
const worldSeedFile = path.join(__dirname, "data", "world-seed.json");
const storySeedFile = path.join(__dirname, "data", "story-seed.json");
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "inn8labs@gmail.com";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "";
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex");
const DATABASE_URL = process.env.DATABASE_URL || "";
const DEFAULT_SETTINGS = {accent:"#d8ad53",storySize:20,choiceConfirm:true};
const WORLD_TYPES = ["location","npc","familiar","special_item","special_weapon","boon"];
const ATTACHABLE_TYPES = WORLD_TYPES.filter(type=>type!=="location");

let pool = null;
let storageMode = "file-fallback";

fs.mkdirSync(dataDir,{recursive:true});
if(!fs.existsSync(savesFile)) fs.writeFileSync(savesFile,"[]");
if(!fs.existsSync(settingsFile)) fs.writeFileSync(settingsFile,JSON.stringify(DEFAULT_SETTINGS,null,2));

const mime = {
  ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8",
  ".js":"application/javascript; charset=utf-8", ".json":"application/json; charset=utf-8",
  ".png":"image/png", ".jpg":"image/jpeg", ".jpeg":"image/jpeg",
  ".webp":"image/webp", ".svg":"image/svg+xml", ".ico":"image/x-icon"
};
const sleep = ms => new Promise(resolve=>setTimeout(resolve,ms));
function json(res,status,value,headers={}){res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store",...headers});res.end(JSON.stringify(value));}
function readJson(req,limit=3_000_000){return new Promise((resolve,reject)=>{let body="";req.on("data",chunk=>{body+=chunk;if(body.length>limit){reject(new Error("too_large"));req.destroy();}});req.on("end",()=>{try{resolve(body?JSON.parse(body):{});}catch(error){reject(error);}});req.on("error",reject);});}
function loadJson(file,fallback){try{if(fs.existsSync(file))return JSON.parse(fs.readFileSync(file,"utf8"));const gz=file+".gz";if(fs.existsSync(gz))return JSON.parse(zlib.gunzipSync(fs.readFileSync(gz)).toString("utf8"));return fallback;}catch{return fallback;}}
function saveJson(file,value){const tmp=file+".tmp";fs.writeFileSync(tmp,JSON.stringify(value,null,2));fs.renameSync(tmp,file);}
function safeEqual(a,b){const A=Buffer.from(String(a)),B=Buffer.from(String(b));return A.length===B.length&&crypto.timingSafeEqual(A,B);}
function signSession(payload){const data=Buffer.from(JSON.stringify(payload)).toString("base64url");const sig=crypto.createHmac("sha256",SESSION_SECRET).update(data).digest("base64url");return `${data}.${sig}`;}
function verifySession(token){if(!token||!token.includes("."))return null;const [data,sig]=token.split(".");const expected=crypto.createHmac("sha256",SESSION_SECRET).update(data).digest("base64url");if(sig.length!==expected.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))return null;try{const payload=JSON.parse(Buffer.from(data,"base64url").toString("utf8"));return payload.exp>Date.now()?payload:null;}catch{return null;}}
function cookies(req){return Object.fromEntries((req.headers.cookie||"").split(";").filter(Boolean).map(value=>{const i=value.indexOf("=");return [value.slice(0,i).trim(),decodeURIComponent(value.slice(i+1))];}));}
function getAdminSession(req){const session=verifySession(cookies(req).fp_admin);return session?.kind==="admin"?session:null;}
function getPlayerSession(req){const session=verifySession(cookies(req).fp_player);return session?.kind==="player"?session:null;}
function requireAdmin(req,res){const session=getAdminSession(req);if(!session){json(res,401,{ok:false,error:"Unauthorized"});return null;}return session;}
function requirePlayer(req,res){const session=getPlayerSession(req);if(!session){json(res,401,{ok:false,error:"Please sign in"});return null;}return session;}
function normalizeEmail(value){return String(value||"").trim().toLowerCase();}
function validEmail(value){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)&&value.length<=254;}
function validPassword(value){return typeof value==="string"&&value.length>=8&&value.length<=128;}
function hashPassword(password){const salt=crypto.randomBytes(16).toString("hex");const hash=crypto.scryptSync(password,salt,64).toString("hex");return `${salt}:${hash}`;}
function verifyPassword(password,stored){try{const [salt,hex]=String(stored||"").split(":");if(!salt||!hex)return false;const actual=crypto.scryptSync(password,salt,64),expected=Buffer.from(hex,"hex");return actual.length===expected.length&&crypto.timingSafeEqual(actual,expected);}catch{return false;}}
function claimHash(token){return token?crypto.createHash("sha256").update(String(token)).digest("hex"):null;}
function playerCookie(token,maxAge=2_592_000){return `fp_player=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}; Secure`;}
function cleanId(value){const id=String(value||"").trim();return /^[A-Za-z][A-Za-z0-9_-]{1,63}$/.test(id)?id:null;}
function cleanType(value){return WORLD_TYPES.includes(value)?value:null;}
function deepClone(value){return value==null?value:JSON.parse(JSON.stringify(value));}
function sendFile(res,filePath){fs.readFile(filePath,(err,data)=>{if(err){res.writeHead(err.code==="ENOENT"?404:500,{"Content-Type":"text/plain; charset=utf-8"});res.end(err.code==="ENOENT"?"Not found":"Server error");return;}const ext=path.extname(filePath).toLowerCase();const cache=ext===".html"?"no-cache":"public, max-age=300";res.writeHead(200,{"Content-Type":mime[ext]||"application/octet-stream","Cache-Control":cache});res.end(data);});}

async function initializePostgres(){
  if(!DATABASE_URL||!Pool)return false;
  const candidate=new Pool({connectionString:DATABASE_URL,max:8,idleTimeoutMillis:30_000});
  let lastError;
  for(let attempt=1;attempt<=20;attempt++){
    try{
      await candidate.query("SELECT 1");
      await candidate.query(`CREATE TABLE IF NOT EXISTS player_accounts(id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
      await candidate.query(`CREATE TABLE IF NOT EXISTS character_saves(id TEXT PRIMARY KEY,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),avatar JSONB,state JSONB NOT NULL,history JSONB NOT NULL DEFAULT '[]'::jsonb)`);
      await candidate.query(`ALTER TABLE character_saves ADD COLUMN IF NOT EXISTS owner_id TEXT REFERENCES player_accounts(id) ON DELETE SET NULL`);
      await candidate.query(`ALTER TABLE character_saves ADD COLUMN IF NOT EXISTS claim_token_hash TEXT`);
      await candidate.query(`CREATE INDEX IF NOT EXISTS character_saves_updated_at_idx ON character_saves(updated_at DESC)`);
      await candidate.query(`CREATE INDEX IF NOT EXISTS character_saves_owner_id_idx ON character_saves(owner_id,updated_at DESC)`);
      await candidate.query(`CREATE TABLE IF NOT EXISTS app_settings(id INTEGER PRIMARY KEY CHECK(id=1),settings JSONB NOT NULL,updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
      await candidate.query(`INSERT INTO app_settings(id,settings) VALUES(1,$1::jsonb) ON CONFLICT(id) DO NOTHING`,[JSON.stringify(DEFAULT_SETTINGS)]);
      await candidate.query(`CREATE TABLE IF NOT EXISTS world_entities(id TEXT NOT NULL,type TEXT NOT NULL,draft JSONB NOT NULL,published JSONB,version INTEGER NOT NULL DEFAULT 0,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),published_at TIMESTAMPTZ,PRIMARY KEY(type,id))`);
      await candidate.query(`CREATE INDEX IF NOT EXISTS world_entities_type_idx ON world_entities(type,updated_at DESC)`);
      await candidate.query(`CREATE TABLE IF NOT EXISTS world_entity_versions(version_id BIGSERIAL PRIMARY KEY,type TEXT NOT NULL,entity_id TEXT NOT NULL,version INTEGER NOT NULL,snapshot JSONB NOT NULL,published_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
      await candidate.query(`CREATE INDEX IF NOT EXISTS world_entity_versions_lookup_idx ON world_entity_versions(type,entity_id,version DESC)`);
      await candidate.query(`CREATE TABLE IF NOT EXISTS story_scenes(id TEXT PRIMARY KEY,draft JSONB NOT NULL,published JSONB,core BOOLEAN NOT NULL DEFAULT FALSE,version INTEGER NOT NULL DEFAULT 0,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),published_at TIMESTAMPTZ)`);
      await candidate.query(`CREATE TABLE IF NOT EXISTS story_scene_versions(version_id BIGSERIAL PRIMARY KEY,scene_id TEXT NOT NULL,version INTEGER NOT NULL,snapshot JSONB NOT NULL,published_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
      await candidate.query(`CREATE INDEX IF NOT EXISTS story_scene_versions_lookup_idx ON story_scene_versions(scene_id,version DESC)`);
      pool=candidate;storageMode="postgres";
      await migrateFallbackData();
      await seedWorldBuilder();
      return true;
    }catch(error){lastError=error;if(attempt<20)await sleep(1000);}
  }
  await candidate.end().catch(()=>{});
  console.error("Postgres unavailable; using file fallback:",lastError?.message||lastError);
  return false;
}

async function migrateFallbackData(){
  if(!pool)return;
  const count=await pool.query("SELECT COUNT(*)::int AS count FROM character_saves");
  if(Number(count.rows[0]?.count||0)===0){
    for(const record of loadJson(savesFile,[])){
      if(!record?.id||!record?.state)continue;
      await pool.query(`INSERT INTO character_saves(id,created_at,updated_at,avatar,state,history) VALUES($1,$2,$3,$4::jsonb,$5::jsonb,$6::jsonb) ON CONFLICT(id) DO NOTHING`,[
        String(record.id),record.createdAt||new Date().toISOString(),record.updatedAt||new Date().toISOString(),JSON.stringify(record.avatar??null),JSON.stringify(record.state),JSON.stringify(Array.isArray(record.history)?record.history.slice(-500):[])
      ]);
    }
  }
  const existing=await pool.query("SELECT settings FROM app_settings WHERE id=1");
  if(existing.rows.length&&JSON.stringify(existing.rows[0].settings)===JSON.stringify(DEFAULT_SETTINGS)){
    const fallback=loadJson(settingsFile,DEFAULT_SETTINGS);
    if(JSON.stringify(fallback)!==JSON.stringify(DEFAULT_SETTINGS))await pool.query("UPDATE app_settings SET settings=$1::jsonb,updated_at=NOW() WHERE id=1",[JSON.stringify(fallback)]);
  }
}

async function seedWorldBuilder(){
  if(!pool)return;
  const world=loadJson(worldSeedFile,[]),story=loadJson(storySeedFile,[]);
  for(const item of world){
    const type=cleanType(item.type),id=cleanId(item.id);if(!type||!id)continue;
    const data={...item,id,type};
    await pool.query(`INSERT INTO world_entities(id,type,draft,published,version,published_at) VALUES($1,$2,$3::jsonb,$3::jsonb,1,NOW()) ON CONFLICT(type,id) DO NOTHING`,[id,type,JSON.stringify(data)]);
  }
  for(const item of story){
    const id=cleanId(item.id);if(!id)continue;
    const scene=normalizeScene({...item,id});
    await pool.query(`INSERT INTO story_scenes(id,draft,published,core,version,published_at) VALUES($1,$2::jsonb,$2::jsonb,$3,1,NOW()) ON CONFLICT(id) DO NOTHING`,[id,JSON.stringify(scene),!!scene.core]);
  }
}

function rowToRecord(row){return {id:row.id,createdAt:new Date(row.created_at).toISOString(),updatedAt:new Date(row.updated_at).toISOString(),avatar:row.avatar,state:row.state,history:Array.isArray(row.history)?row.history:[],ownerId:row.owner_id||null};}
function characterSummary(record){return {id:record.id,createdAt:record.createdAt,updatedAt:record.updatedAt,avatar:record.avatar,name:record.state?.player?.name||"Traveler",origin:record.state?.player?.origin,style:record.state?.player?.style,health:record.state?.player?.health,maxHealth:record.state?.player?.maxHealth,gold:record.state?.player?.gold,reputation:record.state?.player?.reputation,location:record.state?.world?.location,day:record.state?.world?.day,scene:record.state?.scene,companion:record.state?.companion?.name||record.state?.companion?.kind||null,historyCount:record.history?.length||0};}
async function getSettings(){if(pool){const result=await pool.query("SELECT settings FROM app_settings WHERE id=1");return result.rows[0]?.settings||DEFAULT_SETTINGS;}return loadJson(settingsFile,DEFAULT_SETTINGS);}
async function setSettings(settings){if(pool){await pool.query(`INSERT INTO app_settings(id,settings,updated_at) VALUES(1,$1::jsonb,NOW()) ON CONFLICT(id) DO UPDATE SET settings=EXCLUDED.settings,updated_at=NOW()`,[JSON.stringify(settings)]);return;}saveJson(settingsFile,settings);}
async function listCharacters(){if(pool){const result=await pool.query("SELECT id,created_at,updated_at,avatar,state,history,owner_id FROM character_saves ORDER BY updated_at DESC LIMIT 1000");return result.rows.map(rowToRecord);}return loadJson(savesFile,[]);}
async function getCharacter(id){if(pool){const result=await pool.query("SELECT id,created_at,updated_at,avatar,state,history,owner_id FROM character_saves WHERE id=$1",[id]);return result.rows[0]?rowToRecord(result.rows[0]):null;}return loadJson(savesFile,[]).find(row=>row.id===id)||null;}
async function listPlayerCharacters(userId){if(!pool)return [];const result=await pool.query("SELECT id,created_at,updated_at,avatar,state,history,owner_id FROM character_saves WHERE owner_id=$1 ORDER BY updated_at DESC",[userId]);return result.rows.map(rowToRecord);}

async function upsertCharacter(body,playerSession){
  const id=String(body.id||crypto.randomUUID()),avatar=body.avatar??null,history=Array.isArray(body.history)?body.history.slice(-500):[],tokenHash=claimHash(body.claimToken);
  if(pool){
    const existing=await pool.query("SELECT owner_id,claim_token_hash FROM character_saves WHERE id=$1",[id]);
    if(existing.rows.length){
      const row=existing.rows[0];
      if(row.owner_id&&(!playerSession||row.owner_id!==playerSession.userId)){const error=new Error("forbidden");error.code="forbidden";throw error;}
      if(!row.owner_id&&row.claim_token_hash&&(!tokenHash||!safeEqual(row.claim_token_hash,tokenHash))){const error=new Error("claim_mismatch");error.code="claim_mismatch";throw error;}
      await pool.query(`UPDATE character_saves SET updated_at=NOW(),avatar=$2::jsonb,state=$3::jsonb,history=$4::jsonb,claim_token_hash=COALESCE(claim_token_hash,$5),owner_id=COALESCE(owner_id,$6) WHERE id=$1`,[id,JSON.stringify(avatar),JSON.stringify(body.state),JSON.stringify(history),tokenHash,playerSession?.userId||null]);
      return id;
    }
    await pool.query(`INSERT INTO character_saves(id,avatar,state,history,owner_id,claim_token_hash) VALUES($1,$2::jsonb,$3::jsonb,$4::jsonb,$5,$6)`,[id,JSON.stringify(avatar),JSON.stringify(body.state),JSON.stringify(history),playerSession?.userId||null,tokenHash]);
    return id;
  }
  const saves=loadJson(savesFile,[]),now=new Date().toISOString(),current=saves.find(row=>row.id===id),record={id,createdAt:current?.createdAt||now,updatedAt:now,avatar:avatar||current?.avatar||null,state:body.state,history:history.length?history:current?.history||[]};
  saveJson(savesFile,(current?saves.map(row=>row.id===id?record:row):[record,...saves]).slice(0,1000));return id;
}
async function createPlayerAccount(email,password){if(!pool){const error=new Error("storage");error.code="storage";throw error;}const id=crypto.randomUUID();try{await pool.query("INSERT INTO player_accounts(id,email,password_hash) VALUES($1,$2,$3)",[id,email,hashPassword(password)]);return {id,email};}catch(error){if(error.code==="23505"){const duplicate=new Error("duplicate");duplicate.code="duplicate";throw duplicate;}throw error;}}
async function authenticatePlayer(email,password){if(!pool)return null;const result=await pool.query("SELECT id,email,password_hash FROM player_accounts WHERE email=$1",[email]);const row=result.rows[0];if(!row||!verifyPassword(password,row.password_hash))return null;await pool.query("UPDATE player_accounts SET updated_at=NOW() WHERE id=$1",[row.id]);return {id:row.id,email:row.email};}
async function claimCharacter(userId,id,claimToken){if(!pool){const error=new Error("storage");error.code="storage";throw error;}const result=await pool.query("SELECT owner_id,claim_token_hash FROM character_saves WHERE id=$1",[id]);if(!result.rows.length){const error=new Error("missing");error.code="missing";throw error;}const row=result.rows[0];if(row.owner_id===userId)return true;if(row.owner_id){const error=new Error("owned");error.code="owned";throw error;}const tokenHash=claimHash(claimToken);if(!row.claim_token_hash||!tokenHash||!safeEqual(row.claim_token_hash,tokenHash)){const error=new Error("claim");error.code="claim";throw error;}await pool.query("UPDATE character_saves SET owner_id=$2,updated_at=NOW() WHERE id=$1",[id,userId]);return true;}

function normalizeEntity(type,id,input){
  const data=deepClone(input||{});data.id=id;data.type=type;data.name=String(data.name||id).slice(0,120);data.description=String(data.description||"").slice(0,12_000);data.tags=Array.isArray(data.tags)?data.tags.map(String).slice(0,40):[];
  if(type!=="location")data.locationIds=Array.isArray(data.locationIds)?[...new Set(data.locationIds.map(cleanId).filter(Boolean))].slice(0,50):[];
  if(type==="location"){
    data.kind=String(data.kind||"location").slice(0,80);data.coord=String(data.coord||"").slice(0,80);data.public=!!data.public;
    data.map={x:Math.max(0,Math.min(100,Number(data.map?.x)||50)),y:Math.max(0,Math.min(100,Number(data.map?.y)||50))};
  }
  return data;
}
function normalizeChoice(choice,index){return {id:cleanId(choice?.id)||`choice${index+1}`,text:String(choice?.text||`Choice ${index+1}`).slice(0,500),next:cleanId(choice?.next)||null,action:["map","journal","inventory","character","save"].includes(choice?.action)?choice.action:null,conditions:Array.isArray(choice?.conditions)?choice.conditions.slice(0,20):[],effects:Array.isArray(choice?.effects)?choice.effects.slice(0,30):[]};}
function normalizeScene(input){
  const id=cleanId(input.id)||"scene";return {id,chapter:String(input.chapter||"FORKED PATHS").slice(0,160),core:!!input.core,locationId:cleanId(input.locationId)||null,inheritNarrative:input.inheritNarrative===true,inheritChoices:input.inheritChoices===true,narrative:Array.isArray(input.narrative)?input.narrative.slice(0,60).map(block=>({text:String(block?.text||"").slice(0,12_000),kind:block?.kind==="system"?"system":"paragraph",conditions:Array.isArray(block?.conditions)?block.conditions.slice(0,20):[]})):[],choices:Array.isArray(input.choices)?input.choices.slice(0,30).map(normalizeChoice):[],onEnter:Array.isArray(input.onEnter)?input.onEnter.slice(0,30):[],tags:Array.isArray(input.tags)?input.tags.map(String).slice(0,40):[],archived:!!input.archived};
}
async function listWorldAdmin(type=null){if(!pool)return [];const params=[],where=[];if(type){params.push(type);where.push(`type=$${params.length}`);}const result=await pool.query(`SELECT id,type,draft,published,version,created_at,updated_at,published_at,(published IS NULL OR draft IS DISTINCT FROM published) AS dirty FROM world_entities ${where.length?`WHERE ${where.join(" AND ")}`:""} ORDER BY type,(draft->>'name') NULLS LAST,id`,params);return result.rows.map(row=>({...row,createdAt:new Date(row.created_at).toISOString(),updatedAt:new Date(row.updated_at).toISOString(),publishedAt:row.published_at?new Date(row.published_at).toISOString():null}));}
async function getWorldAdmin(type,id){if(!pool)return null;const result=await pool.query(`SELECT id,type,draft,published,version,created_at,updated_at,published_at,(published IS NULL OR draft IS DISTINCT FROM published) AS dirty FROM world_entities WHERE type=$1 AND id=$2`,[type,id]);return result.rows[0]||null;}
async function saveWorldDraft(type,id,input){if(!pool)throw new Error("storage");const data=normalizeEntity(type,id,input);await pool.query(`INSERT INTO world_entities(id,type,draft) VALUES($1,$2,$3::jsonb) ON CONFLICT(type,id) DO UPDATE SET draft=EXCLUDED.draft,updated_at=NOW()`,[id,type,JSON.stringify(data)]);return getWorldAdmin(type,id);}
async function publishWorld(type,id,client=pool){const result=await client.query("SELECT draft,version FROM world_entities WHERE type=$1 AND id=$2 FOR UPDATE",[type,id]);if(!result.rows.length)return null;const nextVersion=Number(result.rows[0].version||0)+1,snapshot=result.rows[0].draft;await client.query("UPDATE world_entities SET published=draft,version=$3,published_at=NOW(),updated_at=NOW() WHERE type=$1 AND id=$2",[type,id,nextVersion]);await client.query("INSERT INTO world_entity_versions(type,entity_id,version,snapshot) VALUES($1,$2,$3,$4::jsonb)",[type,id,nextVersion,JSON.stringify(snapshot)]);return nextVersion;}
async function listStoryAdmin(){if(!pool)return [];const result=await pool.query(`SELECT id,draft,published,core,version,created_at,updated_at,published_at,(published IS NULL OR draft IS DISTINCT FROM published) AS dirty FROM story_scenes ORDER BY COALESCE((draft->>'chapter'),''),id`);return result.rows;}
async function getStoryAdmin(id){if(!pool)return null;const result=await pool.query(`SELECT id,draft,published,core,version,created_at,updated_at,published_at,(published IS NULL OR draft IS DISTINCT FROM published) AS dirty FROM story_scenes WHERE id=$1`,[id]);return result.rows[0]||null;}
async function saveStoryDraft(id,input){if(!pool)throw new Error("storage");const existing=await getStoryAdmin(id),scene=normalizeScene({...input,id,core:existing?.core||input.core});await pool.query(`INSERT INTO story_scenes(id,draft,core) VALUES($1,$2::jsonb,$3) ON CONFLICT(id) DO UPDATE SET draft=EXCLUDED.draft,core=story_scenes.core OR EXCLUDED.core,updated_at=NOW()`,[id,JSON.stringify(scene),!!scene.core]);return getStoryAdmin(id);}
async function publishStory(id,client=pool){const result=await client.query("SELECT draft,version FROM story_scenes WHERE id=$1 FOR UPDATE",[id]);if(!result.rows.length)return null;const nextVersion=Number(result.rows[0].version||0)+1,snapshot=result.rows[0].draft;await client.query("UPDATE story_scenes SET published=draft,version=$2,published_at=NOW(),updated_at=NOW() WHERE id=$1",[id,nextVersion]);await client.query("INSERT INTO story_scene_versions(scene_id,version,snapshot) VALUES($1,$2,$3::jsonb)",[id,nextVersion,JSON.stringify(snapshot)]);return nextVersion;}
async function publicWorld(){if(!pool)return {};const result=await pool.query("SELECT id,type,published FROM world_entities WHERE published IS NOT NULL AND COALESCE((published->>'archived')::boolean,false)=false ORDER BY type,id");const grouped=Object.fromEntries(WORLD_TYPES.map(type=>[type,{}]));for(const row of result.rows)grouped[row.type][row.id]=row.published;return grouped;}
async function publicStory(){if(!pool)return {};const result=await pool.query("SELECT id,published FROM story_scenes WHERE published IS NOT NULL AND COALESCE((published->>'archived')::boolean,false)=false ORDER BY id");return Object.fromEntries(result.rows.map(row=>[row.id,row.published]));}

function getPath(object,pathValue){return String(pathValue||"").split(".").filter(Boolean).reduce((value,key)=>value==null?undefined:value[key],object);}
async function inspectStory(sceneId,useDraft=true){
  if(!pool)return null;const rows=await listStoryAdmin(),map=new Map(rows.map(row=>[row.id,useDraft?row.draft:(row.published||row.draft)])),scene=map.get(sceneId);if(!scene)return null;
  const incoming=[],outgoing=[],missing=[];for(const [id,data] of map){for(const choice of data?.choices||[]){if(choice.next===sceneId)incoming.push(id);if(id===sceneId&&choice.next){outgoing.push(choice.next);if(!map.has(choice.next))missing.push(choice.next);}}}
  const count=await pool.query("SELECT COUNT(*)::int AS count FROM character_saves WHERE state->>'scene'=$1",[sceneId]);
  const refs=[];if(scene.locationId)refs.push({type:"location",id:scene.locationId,via:"scene location"});for(const effect of [...(scene.onEnter||[]),...(scene.choices||[]).flatMap(choice=>choice.effects||[])]){const typeMap={discoverLocation:"location",setLocation:"location",addItem:"special_item",addWeapon:"special_weapon",addBoon:"boon",addFamiliar:"familiar"};if(typeMap[effect?.type]&&cleanId(effect.value))refs.push({type:typeMap[effect.type],id:effect.value,via:effect.type});}
  return {id:sceneId,incoming:[...new Set(incoming)],outgoing:[...new Set(outgoing)],missing:[...new Set(missing)],charactersHere:Number(count.rows[0]?.count||0),references:refs};
}
async function validateStory(useDraft=true){
  const rows=await listStoryAdmin(),scenes=new Map(rows.filter(row=>useDraft||row.published).map(row=>[row.id,useDraft?row.draft:row.published]));const missing=[],deadEnds=[];
  for(const [id,scene] of scenes){const choices=scene?.choices||[];let hasExit=false;for(const choice of choices){if(choice.next){hasExit=true;if(!scenes.has(choice.next))missing.push({scene:id,target:choice.next});}if(choice.action)hasExit=true;}if(!hasExit&&!scene.archived)deadEnds.push(id);}
  const reachable=new Set(),queue=scenes.has("opening")?["opening"]:[];while(queue.length){const id=queue.shift();if(reachable.has(id))continue;reachable.add(id);for(const choice of scenes.get(id)?.choices||[])if(choice.next&&scenes.has(choice.next)&&!reachable.has(choice.next))queue.push(choice.next);}
  const unreachable=[...scenes.keys()].filter(id=>!reachable.has(id)&&!scenes.get(id)?.archived);
  const saved=await pool.query("SELECT DISTINCT state->>'scene' AS scene,COUNT(*)::int AS count FROM character_saves GROUP BY state->>'scene'");const stranded=saved.rows.filter(row=>row.scene&&!scenes.has(row.scene)).map(row=>({scene:row.scene,count:Number(row.count)}));
  return {missing,deadEnds,unreachable,stranded,sceneCount:scenes.size,reachableCount:reachable.size};
}
async function getLocationAttachments(locationId,usePublished=false){
  const world=await listWorldAdmin(),story=await listStoryAdmin(),entities={};for(const type of ATTACHABLE_TYPES)entities[type]=[];
  for(const row of world){if(row.type==="location")continue;const data=usePublished?row.published:row.draft;if(data?.locationIds?.includes(locationId))entities[row.type].push({id:row.id,name:data.name||row.id,dirty:row.dirty});}
  const scenes=story.filter(row=>(usePublished?row.published:row.draft)?.locationId===locationId).map(row=>({id:row.id,chapter:(usePublished?row.published:row.draft)?.chapter||row.id,dirty:row.dirty}));return {entities,scenes};
}
async function setLocationAttachments(locationId,payload){
  const desired=payload?.entities||{},desiredScenes=new Set((payload?.scenes||[]).map(cleanId).filter(Boolean)),rows=await listWorldAdmin();
  for(const row of rows){if(!ATTACHABLE_TYPES.includes(row.type))continue;const wanted=new Set((desired[row.type]||[]).map(cleanId).filter(Boolean)),data=deepClone(row.draft);const locations=new Set(Array.isArray(data.locationIds)?data.locationIds:[]);if(wanted.has(row.id))locations.add(locationId);else locations.delete(locationId);data.locationIds=[...locations];await pool.query("UPDATE world_entities SET draft=$3::jsonb,updated_at=NOW() WHERE type=$1 AND id=$2",[row.type,row.id,JSON.stringify(data)]);}
  const story=await listStoryAdmin();for(const row of story){const data=deepClone(row.draft);if(desiredScenes.has(row.id))data.locationId=locationId;else if(data.locationId===locationId)data.locationId=null;await pool.query("UPDATE story_scenes SET draft=$2::jsonb,updated_at=NOW() WHERE id=$1",[row.id,JSON.stringify(data)]);}
}
async function publishAll(){
  if(!pool)throw new Error("storage");const client=await pool.connect();try{await client.query("BEGIN");const world=await client.query("SELECT type,id FROM world_entities WHERE published IS NULL OR draft IS DISTINCT FROM published");const story=await client.query("SELECT id FROM story_scenes WHERE published IS NULL OR draft IS DISTINCT FROM published");for(const row of world.rows)await publishWorld(row.type,row.id,client);for(const row of story.rows)await publishStory(row.id,client);await client.query("COMMIT");return {world:world.rowCount,story:story.rowCount};}catch(error){await client.query("ROLLBACK");throw error;}finally{client.release();}
}
async function overview(){
  if(!pool)return {storage:storageMode};const typeCounts=await pool.query("SELECT type,COUNT(*)::int AS count,COUNT(*) FILTER(WHERE published IS NULL OR draft IS DISTINCT FROM published)::int AS dirty FROM world_entities GROUP BY type ORDER BY type"),story=await pool.query("SELECT COUNT(*)::int AS count,COUNT(*) FILTER(WHERE published IS NULL OR draft IS DISTINCT FROM published)::int AS dirty FROM story_scenes"),characters=await pool.query("SELECT COUNT(*)::int AS count FROM character_saves"),accounts=await pool.query("SELECT COUNT(*)::int AS count FROM player_accounts"),validation=await validateStory(true);return {version:VERSION,storage:storageMode,world:Object.fromEntries(typeCounts.rows.map(row=>[row.type,{count:Number(row.count),dirty:Number(row.dirty)}])),story:{count:Number(story.rows[0]?.count||0),dirty:Number(story.rows[0]?.dirty||0)},characters:Number(characters.rows[0]?.count||0),accounts:Number(accounts.rows[0]?.count||0),validation};
}

const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url||"/",`http://${req.headers.host||"localhost"}`),pathname=decodeURIComponent(url.pathname);
  try{
    if(pathname==="/health")return json(res,200,{ok:true,game:"Forked Paths",version:VERSION,storage:storageMode,worldBuilder:!!pool});
    if(pathname==="/api/settings"&&req.method==="GET")return json(res,200,await getSettings());
    if(pathname==="/api/story"&&req.method==="GET")return json(res,200,{version:VERSION,scenes:await publicStory()});
    if(pathname==="/api/world"&&req.method==="GET")return json(res,200,{version:VERSION,entities:await publicWorld()});

    if(pathname==="/api/player/register"&&req.method==="POST"){
      if(!pool)return json(res,503,{ok:false,error:"Player accounts are temporarily unavailable"});const body=await readJson(req,20_000),email=normalizeEmail(body.email),password=body.password;if(!validEmail(email))return json(res,400,{ok:false,error:"Enter a valid email address"});if(!validPassword(password))return json(res,400,{ok:false,error:"Password must be 8–128 characters"});try{const account=await createPlayerAccount(email,password),token=signSession({kind:"player",userId:account.id,email:account.email,exp:Date.now()+2_592_000_000});return json(res,201,{ok:true,email:account.email},{"Set-Cookie":playerCookie(token)});}catch(error){if(error.code==="duplicate")return json(res,409,{ok:false,error:"An account already uses that email"});throw error;}
    }
    if(pathname==="/api/player/login"&&req.method==="POST"){
      if(!pool)return json(res,503,{ok:false,error:"Player accounts are temporarily unavailable"});const body=await readJson(req,20_000),email=normalizeEmail(body.email),account=await authenticatePlayer(email,body.password||"");if(!account)return json(res,401,{ok:false,error:"Invalid email or password"});const token=signSession({kind:"player",userId:account.id,email:account.email,exp:Date.now()+2_592_000_000});return json(res,200,{ok:true,email:account.email},{"Set-Cookie":playerCookie(token)});
    }
    if(pathname==="/api/player/logout"&&req.method==="POST")return json(res,200,{ok:true},{"Set-Cookie":playerCookie("",0)});
    if(pathname==="/api/player/session"&&req.method==="GET"){const session=requirePlayer(req,res);if(!session)return;return json(res,200,{ok:true,email:session.email});}
    if(pathname==="/api/player/characters"&&req.method==="GET"){const session=requirePlayer(req,res);if(!session)return;return json(res,200,{characters:(await listPlayerCharacters(session.userId)).map(characterSummary)});}
    if(/^\/api\/player\/characters\/[^/]+$/.test(pathname)&&req.method==="GET"){const session=requirePlayer(req,res);if(!session)return;const id=decodeURIComponent(pathname.split("/").pop()),record=await getCharacter(id);if(!record||record.ownerId!==session.userId)return json(res,404,{ok:false,error:"Character not found"});return json(res,200,record);}
    if(pathname==="/api/player/claim"&&req.method==="POST"){const session=requirePlayer(req,res);if(!session)return;try{const body=await readJson(req,20_000);await claimCharacter(session.userId,String(body.id||""),String(body.claimToken||""));return json(res,200,{ok:true});}catch(error){if(error.code==="missing")return json(res,404,{ok:false,error:"Character not found"});if(error.code==="owned")return json(res,409,{ok:false,error:"That character is already linked to another account"});if(error.code==="claim")return json(res,403,{ok:false,error:"This device cannot verify ownership of that character"});throw error;}}
    if(pathname==="/api/save"&&req.method==="POST"){try{const body=await readJson(req);if(!body.state?.player?.name)return json(res,400,{ok:false,error:"Invalid save"});const id=await upsertCharacter(body,getPlayerSession(req));return json(res,200,{ok:true,id});}catch(error){if(error.code==="forbidden")return json(res,403,{ok:false,error:"Sign in to the account that owns this character"});if(error.code==="claim_mismatch")return json(res,403,{ok:false,error:"This device cannot verify this character"});return json(res,error.message==="too_large"?413:400,{ok:false,error:"Could not save"});}}

    if(pathname==="/api/admin/login"&&req.method==="POST"){if(!ADMIN_PASSWORD)return json(res,503,{ok:false,error:"Admin login is not configured"});const body=await readJson(req,10_000);if(!safeEqual(body.email||"",ADMIN_EMAIL)||!safeEqual(body.password||"",ADMIN_PASSWORD))return json(res,401,{ok:false,error:"Invalid credentials"});const token=signSession({kind:"admin",email:ADMIN_EMAIL,exp:Date.now()+43_200_000});return json(res,200,{ok:true,email:ADMIN_EMAIL},{"Set-Cookie":`fp_admin=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200; Secure`});}
    if(pathname==="/api/admin/logout"&&req.method==="POST")return json(res,200,{ok:true},{"Set-Cookie":"fp_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0; Secure"});
    if(pathname==="/api/admin/session"&&req.method==="GET"){const session=requireAdmin(req,res);if(!session)return;return json(res,200,{ok:true,email:session.email,version:VERSION});}
    if(pathname==="/api/admin/settings"&&req.method==="PUT"){if(!requireAdmin(req,res))return;const body=await readJson(req,100_000),next={accent:/^#[0-9a-f]{6}$/i.test(body.accent||"")?body.accent:"#d8ad53",storySize:Math.max(16,Math.min(28,Number(body.storySize)||20)),choiceConfirm:body.choiceConfirm!==false};await setSettings(next);return json(res,200,{ok:true,settings:next});}
    if(pathname==="/api/admin/overview"&&req.method==="GET"){if(!requireAdmin(req,res))return;return json(res,200,await overview());}
    if(pathname==="/api/admin/publish-all"&&req.method==="POST"){if(!requireAdmin(req,res))return;return json(res,200,{ok:true,...await publishAll()});}
    if(pathname==="/api/admin/characters"&&req.method==="GET"){if(!requireAdmin(req,res))return;return json(res,200,{characters:(await listCharacters()).map(characterSummary)});}
    if(/^\/api\/admin\/characters\/[^/]+$/.test(pathname)&&req.method==="GET"){if(!requireAdmin(req,res))return;const id=decodeURIComponent(pathname.split("/").pop()),record=await getCharacter(id);return record?json(res,200,record):json(res,404,{error:"Not found"});}

    if(pathname==="/api/admin/story"&&req.method==="GET"){if(!requireAdmin(req,res))return;const rows=await listStoryAdmin();return json(res,200,{scenes:rows.map(row=>({id:row.id,chapter:row.draft?.chapter||row.id,locationId:row.draft?.locationId||null,core:row.core,version:row.version,dirty:row.dirty,archived:!!row.draft?.archived}))});}
    if(pathname==="/api/admin/story/validate"&&req.method==="GET"){if(!requireAdmin(req,res))return;return json(res,200,await validateStory(true));}
    if(pathname==="/api/admin/story"&&req.method==="POST"){if(!requireAdmin(req,res))return;const body=await readJson(req,1_000_000),id=cleanId(body.id);if(!id)return json(res,400,{ok:false,error:"Scene ID must begin with a letter and contain only letters, numbers, _ or -"});return json(res,200,{ok:true,scene:await saveStoryDraft(id,body)});}
    if(/^\/api\/admin\/story\/[^/]+\/inspect$/.test(pathname)&&req.method==="GET"){if(!requireAdmin(req,res))return;const id=decodeURIComponent(pathname.split("/").slice(-2)[0]);const result=await inspectStory(id,true);return result?json(res,200,result):json(res,404,{error:"Scene not found"});}
    if(/^\/api\/admin\/story\/[^/]+\/versions$/.test(pathname)&&req.method==="GET"){if(!requireAdmin(req,res))return;const id=decodeURIComponent(pathname.split("/").slice(-2)[0]),result=await pool.query("SELECT version,snapshot,published_at FROM story_scene_versions WHERE scene_id=$1 ORDER BY version DESC LIMIT 30",[id]);return json(res,200,{versions:result.rows});}
    if(/^\/api\/admin\/story\/[^/]+\/publish$/.test(pathname)&&req.method==="POST"){if(!requireAdmin(req,res))return;const id=decodeURIComponent(pathname.split("/").slice(-2)[0]),version=await publishStory(id);return version?json(res,200,{ok:true,version}):json(res,404,{error:"Scene not found"});}
    if(/^\/api\/admin\/story\/[^/]+\/restore$/.test(pathname)&&req.method==="POST"){if(!requireAdmin(req,res))return;const id=decodeURIComponent(pathname.split("/").slice(-2)[0]),body=await readJson(req,20_000),result=await pool.query("SELECT snapshot FROM story_scene_versions WHERE scene_id=$1 AND version=$2",[id,Number(body.version)]);if(!result.rows.length)return json(res,404,{error:"Version not found"});await saveStoryDraft(id,result.rows[0].snapshot);return json(res,200,{ok:true});}
    if(/^\/api\/admin\/story\/[^/]+$/.test(pathname)&&req.method==="GET"){if(!requireAdmin(req,res))return;const id=decodeURIComponent(pathname.split("/").pop()),row=await getStoryAdmin(id);return row?json(res,200,row):json(res,404,{error:"Scene not found"});}

    if(pathname==="/api/admin/world"&&req.method==="GET"){if(!requireAdmin(req,res))return;const type=url.searchParams.get("type"),clean=type?cleanType(type):null;if(type&&!clean)return json(res,400,{error:"Invalid world type"});const rows=await listWorldAdmin(clean);return json(res,200,{entities:rows.map(row=>({id:row.id,type:row.type,name:row.draft?.name||row.id,description:row.draft?.description||"",version:row.version,dirty:row.dirty,archived:!!row.draft?.archived,locationIds:row.draft?.locationIds||[]}))});}
    if(pathname==="/api/admin/world"&&req.method==="POST"){if(!requireAdmin(req,res))return;const body=await readJson(req,1_000_000),type=cleanType(body.type),id=cleanId(body.id);if(!type||!id)return json(res,400,{error:"Valid type and ID are required"});return json(res,200,{ok:true,entity:await saveWorldDraft(type,id,body)});}
    if(/^\/api\/admin\/world\/location\/[^/]+\/attachments$/.test(pathname)&&req.method==="GET"){if(!requireAdmin(req,res))return;const id=decodeURIComponent(pathname.split("/").slice(-2)[0]);return json(res,200,await getLocationAttachments(id,false));}
    if(/^\/api\/admin\/world\/location\/[^/]+\/attachments$/.test(pathname)&&req.method==="PUT"){if(!requireAdmin(req,res))return;const id=decodeURIComponent(pathname.split("/").slice(-2)[0]),body=await readJson(req,1_000_000);await setLocationAttachments(id,body);return json(res,200,{ok:true,attachments:await getLocationAttachments(id,false)});}
    if(/^\/api\/admin\/world\/[^/]+\/[^/]+\/versions$/.test(pathname)&&req.method==="GET"){if(!requireAdmin(req,res))return;const parts=pathname.split("/"),type=cleanType(parts[4]),id=decodeURIComponent(parts[5]);if(!type)return json(res,400,{error:"Invalid type"});const result=await pool.query("SELECT version,snapshot,published_at FROM world_entity_versions WHERE type=$1 AND entity_id=$2 ORDER BY version DESC LIMIT 30",[type,id]);return json(res,200,{versions:result.rows});}
    if(/^\/api\/admin\/world\/[^/]+\/[^/]+\/publish$/.test(pathname)&&req.method==="POST"){if(!requireAdmin(req,res))return;const parts=pathname.split("/"),type=cleanType(parts[4]),id=decodeURIComponent(parts[5]);if(!type)return json(res,400,{error:"Invalid type"});const version=await publishWorld(type,id);return version?json(res,200,{ok:true,version}):json(res,404,{error:"Entity not found"});}
    if(/^\/api\/admin\/world\/[^/]+\/[^/]+$/.test(pathname)&&req.method==="GET"){if(!requireAdmin(req,res))return;const parts=pathname.split("/"),type=cleanType(parts[4]),id=decodeURIComponent(parts[5]);if(!type)return json(res,400,{error:"Invalid type"});const row=await getWorldAdmin(type,id);return row?json(res,200,row):json(res,404,{error:"Entity not found"});}

    let filePath;if(pathname==="/admin"||pathname==="/admin/")filePath=path.join(publicDir,"admin.html");else if(pathname==="/contact"||pathname==="/contact/")filePath=path.join(publicDir,"contact.html");else{const p=pathname==="/"?"/index.html":pathname;filePath=path.normalize(path.join(publicDir,p));}
    if(!filePath.startsWith(publicDir)){res.writeHead(403,{"Content-Type":"text/plain; charset=utf-8"});return res.end("Forbidden");}
    fs.stat(filePath,(err,stat)=>{if(!err&&stat.isFile())return sendFile(res,filePath);sendFile(res,path.join(publicDir,"index.html"));});
  }catch(error){console.error("Request failed:",error);if(!res.headersSent)json(res,error.message==="too_large"?413:500,{ok:false,error:error.message==="too_large"?"Request too large":"Server error"});else res.end();}
});

initializePostgres().catch(error=>console.error("Storage initialization failed:",error)).finally(()=>server.listen(PORT,"0.0.0.0",()=>console.log(`Forked Paths v${VERSION} listening on port ${PORT} (${storageMode})`)));
